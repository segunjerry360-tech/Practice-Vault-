# PracticeVault — GitHub Android builds

This repository contains two separate Android WebView applications:
- `PracticeVault-Player` — playback-only HTML interface
- `PracticeVault-Manager` — library management HTML interface

GitHub Actions builds a separate debug APK for each app.

## Build on GitHub
1. Create a new GitHub repository.
2. Upload the **contents** of this folder to the repository root (including `.github`).
3. Push to the `main` branch, or open **Actions → Build PracticeVault Android apps → Run workflow**.
4. Open the completed workflow run and download the two APK artifacts.

## Install
Download each APK artifact, extract it if GitHub downloads it as an archive, and install
the APKs on the Android phone. You may need to allow installation from the browser or
file manager used to download them.

## Important current limitations
- These are Android WebView wrappers around the supplied HTML builds. They are not yet
  native LibVLC applications. Playback formats are limited by Android System WebView's
  media decoder; accepting a file in Manager does not guarantee Player can decode it.
- Both APKs use Android's Storage Access Framework (SAF) and a `.practicevault.json`
  metadata file inside a user-selected folder. In Manager, select a folder (for example
  Movies/PracticeVault) and import videos. In Player, select that exact same folder.
  Each app persists its own permission to the same shared media folder.
- Stay Focused can block the Manager package independently from Player, but this alone
  does not solve the shared-library limitation above.
- These are unsigned debug builds for testing. A release build needs signing configuration.
- The workflow builds APKs; it does not publish them to Google Play.

## Target compatibility
`minSdk 23` supports Android 6.0 and later, including Android 10 on the Samsung Galaxy S9.


    ## Native video decoding
    PracticeVault Player now includes VideoLAN LibVLC Android `3.7.1` (`libvlc-all`).
    The library is used by a dedicated native landscape playback Activity. The HTML
    library screen launches that Activity with the selected shared-folder content URI.
    Playback progress is written back to `.practicevault.json` every few seconds and
    when playback is paused or the Activity closes. The native controls include play/
    pause, seek bar, ±10-second seek and playback-rate adjustment.

    LibVLC is distributed under LGPLv2.1-or-later; review VideoLAN's licensing and
    notices before distributing modified/repackaged releases.
    

    LibVLC playback is implemented as a native landscape playback screen launched
    from the Player library. It uses VideoLAN `libvlc-all:3.7.1`. Native controls include
    play/pause, timeline seeking, ±10-second jumps, playback speed and A-B looping.
    Playback position and duration are written to the shared `.practicevault.json`.
    The library browser remains the HTML interface.
