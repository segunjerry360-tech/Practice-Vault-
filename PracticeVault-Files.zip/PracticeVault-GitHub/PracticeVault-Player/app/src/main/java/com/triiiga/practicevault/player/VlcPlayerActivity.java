package com.triiiga.practicevault.player;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.pm.ActivityInfo;

import androidx.documentfile.provider.DocumentFile;

import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class VlcPlayerActivity extends Activity {
    private LibVLC libVLC;
    private MediaPlayer mediaPlayer;
    private VLCVideoLayout videoLayout;
    private SeekBar seekBar;
    private TextView titleView, timeView, speedView;
    private Button playButton;
    private boolean seeking = false;
    private boolean userSeeking = false;
    private long lastSavedSecond = -1;
    private Uri mediaUri;
    private String displayTitle = "Practice video";
    private String treeUri;
    private float speed = 1.0f;
    private long loopA = -1L, loopB = -1L;
    private Button loopButton;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        mediaUri = Uri.parse(getIntent().getStringExtra("media_uri"));
        displayTitle = getIntent().getStringExtra("title");
        if (displayTitle == null) displayTitle = "Practice video";
        treeUri = getSharedPreferences("pv_shared", MODE_PRIVATE).getString("tree", null);
        long resume = getIntent().getLongExtra("position_ms", 0L);

        buildUi();
        ArrayList<String> options = new ArrayList<>();
        options.add("--no-drop-late-frames");
        options.add("--no-skip-frames");
        libVLC = new LibVLC(this, options);
        mediaPlayer = new MediaPlayer(libVLC);
        mediaPlayer.attachViews(videoLayout, null, false, false);
        mediaPlayer.setEventListener(event -> runOnUiThread(() -> onVlcEvent(event)));
        Media media = new Media(libVLC, mediaUri);
        mediaPlayer.setMedia(media);
        media.release();
        mediaPlayer.play();
        if (resume > 0) {
            videoLayout.postDelayed(() -> {
                if (mediaPlayer != null && mediaPlayer.getLength() > resume) mediaPlayer.setTime(resume);
            }, 700);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        titleView = new TextView(this);
        titleView.setText(displayTitle);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(16);
        titleView.setPadding(16, 10, 16, 10);
        root.addView(titleView, new LinearLayout.LayoutParams(-1, -2));

        videoLayout = new VLCVideoLayout(this);
        root.addView(videoLayout, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setPadding(8, 8, 8, 8);
        controls.setBackgroundColor(Color.rgb(18, 20, 25));

        Button back = button("‹");
        back.setOnClickListener(v -> finish());
        controls.addView(back);

        Button rewind = button("−10s");
        rewind.setOnClickListener(v -> seekBy(-10000));
        controls.addView(rewind);

        playButton = button("Ⅱ");
        playButton.setOnClickListener(v -> {
            if (mediaPlayer == null) return;
            if (mediaPlayer.isPlaying()) mediaPlayer.pause(); else mediaPlayer.play();
        });
        controls.addView(playButton);

        Button forward = button("+10s");
        forward.setOnClickListener(v -> seekBy(10000));
        controls.addView(forward);

        seekBar = new SeekBar(this);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(0, -2, 1f);
        seekParams.setMargins(8, 0, 8, 0);
        controls.addView(seekBar, seekParams);
        seekBar.setMax(1000);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { userSeeking = true; }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                if (mediaPlayer != null && mediaPlayer.getLength() > 0)
                    mediaPlayer.setTime((mediaPlayer.getLength() * bar.getProgress()) / 1000L);
                userSeeking = false;
                saveProgress();
            }
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {}
        });

        timeView = new TextView(this);
        timeView.setTextColor(Color.WHITE);
        timeView.setText("00:00 / 00:00");
        controls.addView(timeView);

        Button slower = button("−");
        slower.setOnClickListener(v -> changeSpeed(-0.25f));
        controls.addView(slower);
        speedView = new TextView(this);
        speedView.setTextColor(Color.WHITE);
        speedView.setPadding(8, 0, 8, 0);
        speedView.setText("1.00×");
        controls.addView(speedView);
        Button faster = button("+");
        faster.setOnClickListener(v -> changeSpeed(0.25f));
        controls.addView(faster);

        loopButton = button("Set A");
        loopButton.setOnClickListener(v -> setLoopPoint());
        controls.addView(loopButton);

        root.addView(controls, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    private void setLoopPoint() {
        if (mediaPlayer == null) return;
        long now = mediaPlayer.getTime();
        if (loopA < 0) {
            loopA = now; loopB = -1L; loopButton.setText("Set B");
            Toast.makeText(this, "A point set", Toast.LENGTH_SHORT).show();
        } else if (loopB < 0) {
            if (now <= loopA) { Toast.makeText(this, "Set B after A", Toast.LENGTH_SHORT).show(); return; }
            loopB = now; loopButton.setText("Clear A-B");
            Toast.makeText(this, "A-B loop enabled", Toast.LENGTH_SHORT).show();
        } else {
            loopA = loopB = -1L; loopButton.setText("Set A");
            Toast.makeText(this, "A-B loop cleared", Toast.LENGTH_SHORT).show();
        }
    }

    private void changeSpeed(float delta) {
        speed = Math.max(0.25f, Math.min(3.0f, speed + delta));
        if (mediaPlayer != null) mediaPlayer.setRate(speed);
        speedView.setText(String.format(java.util.Locale.US, "%.2f×", speed));
    }

    private void seekBy(long delta) {
        if (mediaPlayer == null) return;
        long next = Math.max(0, mediaPlayer.getTime() + delta);
        long length = mediaPlayer.getLength();
        if (length > 0) next = Math.min(next, length);
        mediaPlayer.setTime(next);
    }

    private String clock(long ms) {
        long sec = Math.max(0, ms / 1000);
        long h = sec / 3600, m = (sec % 3600) / 60, s = sec % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, s)
                     : String.format(java.util.Locale.US, "%02d:%02d", m, s);
    }

    private void onVlcEvent(MediaPlayer.Event event) {
        if (event.type == MediaPlayer.Event.Playing) playButton.setText("Ⅱ");
        else if (event.type == MediaPlayer.Event.Paused) playButton.setText("▶");
        else if (event.type == MediaPlayer.Event.EndReached) {
            saveProgress();
            finish();
        } else if (event.type == MediaPlayer.Event.TimeChanged ||
                   event.type == MediaPlayer.Event.LengthChanged) {
            long time = mediaPlayer.getTime(), length = mediaPlayer.getLength();
            if (loopA >= 0 && loopB > loopA && time >= loopB) {
                mediaPlayer.setTime(loopA);
                time = loopA;
            }
            if (!userSeeking && length > 0) seekBar.setProgress((int)Math.min(1000, time * 1000 / length));
            timeView.setText(clock(time) + " / " + clock(length));
            long second = time / 1000;
            if (second != lastSavedSecond && second % 5 == 0) {
                lastSavedSecond = second;
                saveProgress();
            }
        }
    }

    private void saveProgress() {
        if (mediaUri == null || treeUri == null || mediaPlayer == null) return;
        try {
            DocumentFile folder = DocumentFile.fromTreeUri(this, Uri.parse(treeUri));
            if (folder == null) return;
            DocumentFile metaFile = folder.findFile(".practicevault.json");
            JSONObject all = new JSONObject();
            if (metaFile != null) {
                try (InputStream in = getContentResolver().openInputStream(metaFile.getUri())) {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] b = new byte[8192]; int n;
                    while ((n = in.read(b)) > 0) out.write(b, 0, n);
                    all = new JSONObject(out.toString("UTF-8"));
                } catch (Exception ignored) {}
            }
            String id = mediaUri.toString();
            JSONObject row = all.optJSONObject(id);
            if (row == null) row = new JSONObject();
            row.put("position", Math.max(0, mediaPlayer.getTime()) / 1000.0);
            row.put("duration", Math.max(0, mediaPlayer.getLength()) / 1000.0);
            row.put("lastPlayedAt", System.currentTimeMillis());
            all.put(id, row);
            if (metaFile == null) metaFile = folder.createFile("application/json", ".practicevault.json");
            if (metaFile != null) try (OutputStream out = getContentResolver().openOutputStream(metaFile.getUri(), "wt")) {
                out.write(all.toString().getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {}
    }

    @Override protected void onPause() { saveProgress(); super.onPause(); }
    @Override protected void onStop() {
        saveProgress();
        if (mediaPlayer != null) mediaPlayer.stop();
        super.onStop();
    }
    @Override protected void onDestroy() {
        if (mediaPlayer != null) {
            mediaPlayer.detachViews();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        if (libVLC != null) { libVLC.release(); libVLC = null; }
        super.onDestroy();
    }
}
