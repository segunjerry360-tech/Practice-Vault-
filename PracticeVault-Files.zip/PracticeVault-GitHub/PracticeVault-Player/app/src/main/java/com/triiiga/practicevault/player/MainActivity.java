package com.triiiga.practicevault.player;
import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.*;
import android.graphics.Color;
import androidx.documentfile.provider.DocumentFile;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 static final int FOLDER=4101, FILES=4102;
 WebView web; WebViewAssetLoader loader; DocumentFile root;
 String pref="pv_shared", key="tree";
 DocumentFile folder(){
  if(root!=null && root.exists()) return root;
  String s=getSharedPreferences(pref,0).getString(key,null);
  if(s==null)return null;
  try{root=DocumentFile.fromTreeUri(this,Uri.parse(s));}catch(Exception e){return null;}
  return root;
 }
 void chooseFolder(){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
  i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
  startActivityForResult(i,FOLDER);
 }
 void chooseFiles(){
  Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE);
  i.setType("video/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
  i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
  startActivityForResult(i,FILES);
 }
 JSONObject metadata(){
  JSONObject o=new JSONObject(); DocumentFile f=folder(); if(f==null)return o;
  DocumentFile m=f.findFile(".practicevault.json"); if(m==null)return o;
  try(InputStream in=getContentResolver().openInputStream(m.getUri())){
   ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] x=new byte[16384]; int n;
   while((n=in.read(x))>0)b.write(x,0,n); return new JSONObject(b.toString("UTF-8"));
  }catch(Exception e){return o;}
 }
 void saveMeta(JSONObject o){
  DocumentFile f=folder(); if(f==null)return;
  try{DocumentFile m=f.findFile(".practicevault.json"); if(m==null)m=f.createFile("application/json",".practicevault.json");
   if(m!=null)try(OutputStream out=getContentResolver().openOutputStream(m.getUri(),"wt")){out.write(o.toString().getBytes(StandardCharsets.UTF_8));}
  }catch(Exception ignored){}
 }
 String videos(){
  JSONArray a=new JSONArray(); DocumentFile f=folder(); if(f==null)return "[]"; JSONObject meta=metadata();
  for(DocumentFile d:f.listFiles()){
   String n=d.getName(); if(!d.isFile()||n==null||n.equals(".practicevault.json"))continue;
   String mime=d.getType(); if(mime==null)mime="video/*"; if(!mime.startsWith("video/")&&!n.matches("(?i).*\\.(mp4|mkv|avi|mov|wmv|flv|webm|mpg|mpeg|m4v|3gp|ts|mts|m2ts|vob|ogv)$"))continue;
   JSONObject m=meta.optJSONObject(d.getUri().toString()); if(m==null)m=new JSONObject();
   JSONObject r=new JSONObject();
   try{r.put("id",d.getUri().toString());r.put("uri",d.getUri().toString());r.put("fileName",n);
    r.put("title",m.optString("title",n.replaceFirst("\\.[^.]+$","")));r.put("category",m.optString("category","Other"));
    r.put("size",d.length());r.put("position",m.optDouble("position",0));r.put("duration",m.optDouble("duration",0));
    r.put("lastPlayedAt",m.optLong("lastPlayedAt",0));a.put(r);
   }catch(Exception ignored){}
  } return a.toString();
 }
 String name(Uri u){
  try(android.database.Cursor c=getContentResolver().query(u,null,null,null,null)){
   if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}
  }catch(Exception ignored){} return "Practice-video";
 }
 String mime(String n){String x=n.toLowerCase(); if(x.endsWith(".mp4")||x.endsWith(".m4v"))return "video/mp4";if(x.endsWith(".webm"))return "video/webm";if(x.endsWith(".mov"))return "video/quicktime";if(x.endsWith(".mkv"))return "video/x-matroska";return "video/*";}
 void importFiles(Intent data){
  DocumentFile f=folder();int ok=0,bad=0; if(f==null){call("onNativeImportComplete",0,1);return;}
  JSONArray uris=new JSONArray();
  if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.put(data.getClipData().getItemAt(i).getUri().toString());}
  else if(data.getData()!=null)uris.put(data.getData().toString());
  JSONObject meta=metadata();
  for(int i=0;i<uris.length();i++)try{
   Uri src=Uri.parse(uris.getString(i)); String original=name(src), target=original; int k=2;
   while(f.findFile(target)!=null){int dot=original.lastIndexOf('.');target=(dot>0?original.substring(0,dot):original)+" ("+(k++)+")"+(dot>0?original.substring(dot):"");}
   DocumentFile dest=f.createFile(mime(target),target); if(dest==null)throw new IOException();
   try(InputStream in=getContentResolver().openInputStream(src);OutputStream out=getContentResolver().openOutputStream(dest.getUri(),"w")){
    byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);
   }
   JSONObject m=new JSONObject();m.put("title",target.replaceFirst("\\.[^.]+$",""));m.put("category","Other");m.put("position",0);m.put("duration",0);m.put("lastPlayedAt",0);meta.put(dest.getUri().toString(),m);ok++;
  }catch(Exception e){bad++;}
  saveMeta(meta);call("onNativeImportComplete",ok,bad);
 }
 void call(String fn,int a,int b){if(web!=null)web.post(()->web.evaluateJavascript("window."+fn+"&&window."+fn+"("+a+","+b+")",null));}
 public class Bridge{
  @JavascriptInterface public String listVideos(){return videos();}
  @JavascriptInterface public boolean hasFolder(){return folder()!=null;}
  @JavascriptInterface public String folderName(){DocumentFile f=folder();return f==null?"":f.getName();}
  @JavascriptInterface public void chooseFolder(){runOnUiThread(()->MainActivity.this.chooseFolder());}
  @JavascriptInterface public void chooseFiles(){runOnUiThread(()->MainActivity.this.chooseFiles());}
  @JavascriptInterface public void playVideo(String uri,String title,double positionSeconds){
   runOnUiThread(()->{
    Intent i=new Intent(MainActivity.this,VlcPlayerActivity.class);
    i.putExtra("media_uri",uri);i.putExtra("title",title);
    i.putExtra("position_ms",(long)(positionSeconds*1000.0));
    startActivity(i);
   });
  }
  @JavascriptInterface public void update(String id,String title,String category,double pos,double dur,long played){
   JSONObject all=metadata(),m=all.optJSONObject(id);if(m==null)m=new JSONObject();
   try{if(title!=null)m.put("title",title);if(category!=null)m.put("category",category);m.put("position",pos);m.put("duration",dur);m.put("lastPlayedAt",played);all.put(id,m);saveMeta(all);}catch(Exception ignored){}
  }
  @JavascriptInterface public void deleteVideo(String id){
   try{DocumentFile d=DocumentFile.fromSingleUri(MainActivity.this,Uri.parse(id));if(d!=null)d.delete();JSONObject m=metadata();m.remove(id);saveMeta(m);}catch(Exception ignored){}
  }
 }
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(13,16,23));getWindow().setNavigationBarColor(Color.rgb(13,16,23));
  loader=new WebViewAssetLoader.Builder().addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this)).build();
  web=new WebView(this);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setAllowFileAccess(false);s.setAllowContentAccess(true);
  web.addJavascriptInterface(new Bridge(),"PracticeVault");
  web.setWebViewClient(new WebViewClientCompat(){@Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v,android.webkit.WebResourceRequest r){return loader.shouldInterceptRequest(r.getUrl());}});
  web.setWebChromeClient(new WebChromeClient());setContentView(web);web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
 }
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;
  if(req==FOLDER){Uri u=data.getData();int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
   getContentResolver().takePersistableUriPermission(u,flags);getSharedPreferences(pref,0).edit().putString(key,u.toString()).apply();root=DocumentFile.fromTreeUri(this,u);call("onNativeFolderSelected",1,0);
  }else if(req==FILES)importFiles(data);
 }
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(web!=null)web.destroy();super.onDestroy();}
}
